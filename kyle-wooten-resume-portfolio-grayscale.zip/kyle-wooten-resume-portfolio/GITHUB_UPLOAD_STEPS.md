# GitHub Upload Steps

## Option 1: Create the repository through GitHub.com

1. Go to GitHub and select **New repository**.
2. Repository name: `kyle-wooten-resume-portfolio`.
3. Description: `Resume portfolio for IT, cybersecurity, SOC analyst, and class project linking`.
4. Choose **Public** if this will be linked in a class project or portfolio.
5. Do not initialize with a README if you are uploading this package because one is already included.
6. Upload the contents of this folder to the repository.
7. Commit the files.

## Option 2: Create and push from the command line

```bash
cd kyle-wooten-resume-portfolio
git init
git add .
git commit -m "Add resume portfolio package"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/kyle-wooten-resume-portfolio.git
git push -u origin main
```

## Link from the class organization repository

Add this to the class project README:

```md
## Resume Portfolio

- [Kyle Wooten - IT & Cybersecurity Resume Portfolio](https://github.com/YOUR-USERNAME/kyle-wooten-resume-portfolio)
```

## Optional submodule method

Only use this if your instructor wants the repository connected inside the organization repository:

```bash
git submodule add https://github.com/YOUR-USERNAME/kyle-wooten-resume-portfolio.git external/kyle-wooten-resume-portfolio
git commit -m "Add Kyle Wooten resume portfolio submodule"
git push
```
