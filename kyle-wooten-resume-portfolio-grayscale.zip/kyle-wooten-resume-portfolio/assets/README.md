# Assets

Place optional screenshots, diagrams, or portfolio images in this folder.
